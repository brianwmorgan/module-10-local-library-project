function getTotalBooksCount(books) {
  return books.length
}

function getTotalAccountsCount(accounts) {
  return accounts.length
}

function getBooksBorrowedCount(books) {
  let borrowedBooks = 0
  for (let i = 0; i < books.length; i++) {
    if (books[i].borrows[0].returned === false) {
      borrowedBooks += 1
    }
  }
  return borrowedBooks
}

function getMostCommonGenres(books) {
  // firstly, sort books array by genre
  // secondly, count the number of books in each genre
  // thirdly, return a new array of the top 5 genres with count
}

function getMostPopularBooks(books) {

}

function getMostPopularAuthors(books, authors) {

}

module.exports = {
  getTotalBooksCount,
  getTotalAccountsCount,
  getBooksBorrowedCount,
  getMostCommonGenres,
  getMostPopularBooks,
  getMostPopularAuthors,
};
